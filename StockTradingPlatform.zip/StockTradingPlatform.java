package StudentGradeTracker;

import java.util.*;

class Stock {
    String symbol;
    double price;

    Stock(String symbol, double price) {
        this.symbol = symbol;
        this.price = price;
    }

    void updatePrice(double newPrice) {
        this.price = newPrice;
    }

    public String toString() {
        return symbol + " : $" + price;
    }
}

class Portfolio {
    Map<String, Integer> holdings = new HashMap<>();
    double cash;

    Portfolio(double initialCash) {
        this.cash = initialCash;
    }

    void buyStock(Stock stock, int quantity) {
        double cost = stock.price * quantity;
        if (cash >= cost) {
            cash -= cost;
            holdings.put(stock.symbol, holdings.getOrDefault(stock.symbol, 0) + quantity);
            System.out.println("✅ Bought " + quantity + " shares of " + stock.symbol);
        } else {
            System.out.println("❌ Not enough cash to buy.");
        }
    }

    void sellStock(Stock stock, int quantity) {
        int owned = holdings.getOrDefault(stock.symbol, 0);
        if (owned >= quantity) {
            holdings.put(stock.symbol, owned - quantity);
            cash += stock.price * quantity;
            System.out.println("✅ Sold " + quantity + " shares of " + stock.symbol);
        } else {
            System.out.println("❌ Not enough shares to sell.");
        }
    }

    void displayPortfolio(Map<String, Stock> market) {
        System.out.println("\n===== Portfolio Summary =====");
        double totalValue = cash;
        for (String sym : holdings.keySet()) {
            int qty = holdings.get(sym);
            double val = qty * market.get(sym).price;
            totalValue += val;
            System.out.println(sym + " : " + qty + " shares | Value: $" + val);
        }
        System.out.println("Cash: $" + cash);
        System.out.println("Total Portfolio Value: $" + totalValue);
    }
}

public class StockTradingPlatform {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Map<String, Stock> market = new HashMap<>();
        market.put("AAPL", new Stock("AAPL", 150));
        market.put("GOOG", new Stock("GOOG", 2800));
        market.put("TSLA", new Stock("TSLA", 700));

        Portfolio portfolio = new Portfolio(10000); 

        int choice;
        do {
            System.out.println("\n===== Stock Trading Platform =====");
            System.out.println("1. View Market Data");
            System.out.println("2. Buy Stock");
            System.out.println("3. Sell Stock");
            System.out.println("4. View Portfolio");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\nMarket Data:");
                    for (Stock s : market.values()) {
                        System.out.println(s);
                    }
                    break;

                case 2:
                    System.out.print("Enter stock symbol: ");
                    String buySym = sc.next().toUpperCase();
                    if (market.containsKey(buySym)) {
                        System.out.print("Enter quantity: ");
                        int qty = sc.nextInt();
                        portfolio.buyStock(market.get(buySym), qty);
                    } else {
                        System.out.println("❌ Stock not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter stock symbol: ");
                    String sellSym = sc.next().toUpperCase();
                    if (market.containsKey(sellSym)) {
                        System.out.print("Enter quantity: ");
                        int qty = sc.nextInt();
                        portfolio.sellStock(market.get(sellSym), qty);
                    } else {
                        System.out.println("❌ Stock not found!");
                    }
                    break;

                case 4:
                    portfolio.displayPortfolio(market);
                    break;

                case 5:
                    System.out.println("Exiting... Thank you for trading!");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 5);

        sc.close();
    }
}
